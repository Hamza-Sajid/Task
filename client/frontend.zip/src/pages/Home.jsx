import Table from "../components/Table";

function Home() {
  return (
    <div>
      <div className="pt-12">
        <h2 className="text-white text-5xl text-center">Table...</h2>
      </div>

      <Table />
    </div>
  );
}

export default Home;
